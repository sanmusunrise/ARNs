.. _command_prepare_conll_coref:

``neleval prepare-conll-coref``
-------------------------------

Import format from CoNLL 2011-2 coreference shared task for evaluation


Note that CoNLL coreference is not the same as the CoNLL-AIDA named entity
disambiguaiton annotations.

Usage summary
.............

.. command-output:: neleval prepare-conll-coref --help

