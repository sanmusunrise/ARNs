.. _command_prepare_tac15:

``neleval prepare-tac15``
-------------------------

Convert TAC 2015 KBP EL output format for evaluation

Usage summary
.............

.. command-output:: neleval prepare-tac15 --help

