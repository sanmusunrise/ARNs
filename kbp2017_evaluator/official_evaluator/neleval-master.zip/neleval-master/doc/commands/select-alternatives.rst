.. _command_select_alternatives:

``neleval select-alternatives``
-------------------------------

Handle KB ambiguity in the gold standard by modifying it to match system

Usage summary
.............

.. command-output:: neleval select-alternatives --help

