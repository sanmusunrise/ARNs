.. _command_compare_measures:

``neleval compare-measures``
----------------------------

Calculate statistics of measure distribution over systems

Usage summary
.............

.. command-output:: neleval compare-measures --help

