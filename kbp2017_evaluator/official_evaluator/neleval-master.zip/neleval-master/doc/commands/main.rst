.. command_main:

``neleval --help``: usage overview
----------------------------------

.. command-output:: neleval --help

