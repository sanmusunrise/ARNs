.. _command_significance:

``neleval significance``
------------------------

Test for pairwise significance between systems

Usage summary
.............

.. command-output:: neleval significance --help

