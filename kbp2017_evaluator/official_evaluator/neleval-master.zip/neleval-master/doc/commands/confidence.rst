.. _command_confidence:

``neleval confidence``
----------------------

Calculate percentile bootstrap confidence intervals for a system

Usage summary
.............

.. command-output:: neleval confidence --help

