.. _command_rank_systems:

``neleval rank-systems``
------------------------

Get filenames corresponding to best-ranked systems

Usage summary
.............

.. command-output:: neleval rank-systems --help

