.. _command_validate_spans:

``neleval validate-spans``
--------------------------

Identify duplicate, crossing and nested spans

Usage summary
.............

.. command-output:: neleval validate-spans --help

