.. _command_evaluate:

``neleval evaluate``
--------------------

Evaluate system output

Usage summary
.............

.. command-output:: neleval evaluate --help

.. _command_evaluate_by_doc:

Evaluating each document separately
...................................

TODO
