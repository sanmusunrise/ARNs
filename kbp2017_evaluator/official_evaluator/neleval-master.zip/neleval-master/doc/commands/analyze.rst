.. _command_analyze:

``neleval analyze``
-------------------

Analyze errors

Usage summary
.............

.. command-output:: neleval analyze --help

