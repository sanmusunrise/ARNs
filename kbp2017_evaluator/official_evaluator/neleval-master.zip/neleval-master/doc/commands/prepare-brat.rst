.. _command_prepare_brat:

``neleval prepare-brat``
------------------------

Convert brat format for evaluation

Usage summary
.............

.. command-output:: neleval prepare-brat --help

