.. _command_compose_measures:

``neleval compose-measures``
----------------------------

Adds composite measures rows to evaluation output

Usage summary
.............

.. command-output:: neleval compose-measures --help

