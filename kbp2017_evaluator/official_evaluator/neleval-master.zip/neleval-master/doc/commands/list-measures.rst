.. _command_list_measures:

``neleval list-measures``
-------------------------

List measures schemes available for evaluation

Usage summary
.............

.. command-output:: neleval list-measures --help

List all predefined measures
............................

.. command-output:: neleval list-measures
