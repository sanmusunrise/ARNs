.. _command_plot_systems:

``neleval plot-systems``
------------------------

Summarise system results as scatter plots

Usage summary
.............

.. command-output:: neleval plot-systems --help

