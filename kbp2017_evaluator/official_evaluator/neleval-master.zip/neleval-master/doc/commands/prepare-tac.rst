.. _command_prepare_tac:

``neleval prepare-tac``
-----------------------

Convert TAC output format for evaluation

Usage summary
.............

.. command-output:: neleval prepare-tac --help

