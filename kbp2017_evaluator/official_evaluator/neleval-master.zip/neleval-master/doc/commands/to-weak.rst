.. _command_to_weak:

``neleval to-weak``
-------------------

Convert annotations to char-level for weak evaluation.

Usage summary
.............

.. command-output:: neleval to-weak --help

